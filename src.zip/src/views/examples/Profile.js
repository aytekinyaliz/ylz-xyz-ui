/*!

=========================================================
* Argon Dashboard React - v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-react
* Copyright 2019 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import React from 'react';

// reactstrap components
import {
    Button,
    Card,
    CardHeader,
    CardBody,
    FormGroup,
    Form,
    Input,
    Label,
    Container,
    Row,
    FormText,
    Col
} from 'reactstrap';
// core components
import UserHeader from 'components/Headers/UserHeader.js';

class Profile extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            project: [],
            id: props.match.params.id,
            members: [],
            devices: []
        };
    }

    componentDidMount() {
        const projectUrl =
            process.env.REACT_APP_PROJECT_SERVICE_URI + '/api/projects/';
        fetch(projectUrl, {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + localStorage.getItem('token')
            }
        })
            .then(response => response.json())
            .then(response => response.find(item => item.id === this.state.id))
            .then(response => this.setState({ project: response }));

        const membersUrl =
            process.env.REACT_APP_IAM_SERVICE_URI + '/api/users/';
        fetch(membersUrl, {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + localStorage.getItem('token')
            }
        })
            .then(response => response.json())
            // .then(response =>
            //     response.find(item => item.)
            // )
            .then(response => this.setState({ members: response }));

        const devicesUrl =
            process.env.REACT_APP_DEVICE_SERVICE_URI + '/api/devices/';
        fetch(devicesUrl, {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + localStorage.getItem('token')
            }
        })
            .then(response => response.json())
            // .then(response =>
            //     response.find(item => item.)
            // )
            .then(response => this.setState({ devices: response }));
    }

    // handleGoMain = () => {
    //     this.props.history.push('/admin/projects');
    // };

    render() {
        let { project, members, devices } = this.state;
        return !project ? null : (
            <Container className='mt-5' fluid>
                <Row>
                    <Col className='order-xl-1' xl='12'>
                        <Card className='bg-secondary shadow'>
                            <CardHeader className='bg-white border-0'>
                                <Row className='align-items-center'>
                                    <Col xs='8'>
                                        <h2 className='mb-0'>
                                            Name: {project.name}
                                        </h2>
                                    </Col>
                                </Row>
                            </CardHeader>
                            <CardBody>
                                <Form>
                                    <FormGroup row>
                                        <Label
                                            for='exampleEmail'
                                            className='col-sm-2 col-form-label col-form-label-me'
                                        >
                                            Project Owner
                                        </Label>

                                        <Label
                                            for='exampleEmail'
                                            className='col-sm-2 col-form-label col-form-label-me'
                                        >
                                            {project.owner
                                                ? (
                                                      project.owner.firstName +
                                                      ' ' +
                                                      project.owner.lastName
                                                  ).toUpperCase()
                                                : ''}
                                        </Label>
                                    </FormGroup>
                                    <FormGroup row>
                                        <Label
                                            for='examplePassword'
                                            className='col-sm-2 col-form-label col-form-label-me'
                                        >
                                            Members
                                        </Label>
                                        <Label className='col-sm-8 col-form-label col-form-label-me'>
                                            {project.members
                                                ? project.members.map(
                                                      item =>
                                                          item.firstName +
                                                          ' ' +
                                                          item.lastName +
                                                          ','
                                                  )
                                                : ''}
                                        </Label>
                                    </FormGroup>

                                    <FormGroup row>
                                        <Label for='exampleSelect' sm={2}>
                                            Assign Member
                                        </Label>
                                        <Col sm={8}>
                                            <Input
                                                type='select'
                                                name='select'
                                                id='exampleSelect'
                                            >
                                                {members.map(m => (
                                                    <option>
                                                        {m.firstName +
                                                            ' ' +
                                                            m.lastName}
                                                    </option>
                                                ))}
                                            </Input>
                                        </Col>
                                        <Col sm={2}>
                                            <Button color='primary'>
                                                Assign
                                            </Button>
                                        </Col>
                                    </FormGroup>

                                    <FormGroup row>
                                        <Label
                                            for='exampleText'
                                            className='col-sm-2 col-form-label col-form-label-me'
                                        >
                                            Devices
                                        </Label>
                                        <Label className='col-sm-8 col-form-label col-form-label-me'>
                                            {project.devices
                                                ? project.devices.map(
                                                      item => item.name + ', '
                                                  )
                                                : ''}
                                        </Label>
                                    </FormGroup>
                                    <FormGroup row>
                                        <Label for='exampleSelect' sm={2}>
                                            Assign Device
                                        </Label>
                                        <Col sm={8}>
                                            <Input
                                                type='select'
                                                name='select'
                                                id='exampleSelect'
                                            >
                                                {devices.map(d => (
                                                    <option>{d.name}</option>
                                                ))}
                                            </Input>
                                        </Col>
                                        <Col sm={2}>
                                            <Button color='primary'>
                                                Assign
                                            </Button>
                                        </Col>
                                    </FormGroup>
                                    <FormGroup row>
                                        <Label
                                            for='exampleText'
                                            className='col-sm-2 col-form-label col-form-label-me'
                                        >
                                            Files
                                        </Label>
                                        <Label className='col-sm-8 col-form-label col-form-label-me'>
                                            {project.files &&
                                            project.files.length < 1
                                                ? project.files.map(
                                                      item => item + ', '
                                                  )
                                                : ''}
                                        </Label>
                                    </FormGroup>
                                    <FormGroup row>
                                        <Label for='exampleFile' sm={2}>
                                            File
                                        </Label>
                                        <Col sm={10}>
                                            <Input
                                                type='file'
                                                name='file'
                                                id='exampleFile'
                                            />
                                            <FormText color='muted'>
                                                This is some placeholder
                                                block-level help text for the
                                                above input. It's a bit lighter
                                                and easily wraps to a new line.
                                            </FormText>
                                        </Col>
                                    </FormGroup>
                                    <FormGroup check row>
                                        <Col sm={{ size: 10, offset: 2 }}>
                                            <Button
                                                color='primary'
                                                onClick={this.postProject}
                                            >
                                                Create
                                            </Button>
                                        </Col>
                                    </FormGroup>
                                </Form>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </Container>
        );
    }
}

export default Profile;
